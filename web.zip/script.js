// const menu = ['home', 'about us', 'whitepaper', 'roadmap', 'team', 'partners']
// const swiper = new Swiper(".mySwiper", {
//     pagination: {
//         el: '.swiper-pagination',
//               clickable: true,
//           renderBullet: function (index, className) {
//             return '<span class="menu-text' + className + '">' + (menu[index]) + '</span>';
//           },
//       },
//     direction: 'vertical',
//     slidesPerView: 1,
//     paginationClickable: true,
//     spaceBetween: 30,
//     mousewheelControl: true,
//     parallax: true,
//     speed: 600,
//     eventsTarget: ".swiper-slide",
//     breakpoints: {
        
//     }
// })